# WPAlchemy\_MetaBox

For metaboxes, this easy to use class by Dimas Begunoff is included. The only customization is the JavaScript alert message when deleting repeatable items, which has been localized.

Until the need arises for improved or different functionality, this works wonders.

A note outside the documentation that I tend to forget myself: prefix metabox ID with underscore to hide it in the custom fields view.

* [Documentation](http://www.farinspace.com/wpalchemy-metabox/)
* [Github](https://github.com/farinspace/wpalchemy)